package dao;

import model.Socio;
import persistence.NewHibernateUtil;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

public class SocioDaoImplement implements SocioDao{

    @Override
    public ArrayList<Socio> getSocios() {
        Session session = null;
        ArrayList<Socio> socios = null;
        try{
            session = NewHibernateUtil.getSessionFactory().openSession();
            Query query = session.createQuery("from Socio");
            socios = (ArrayList<Socio>) query.list();
        } catch (HibernateException HE){
            System.err.println(HE.getCause());
            System.err.println("Error doing a usuario select.");
        } finally {
            if (session != null){
                session.close();
            }
        }
        return socios;
    }
    
    @Override
    public ArrayList<Socio> getSocios(String user, String password){
        ArrayList<Socio> filteredList = new ArrayList<>();
        ArrayList<Socio> socios = getSocios();
        for (Socio soc: socios){
            if(soc.getUsuario().equals(user) && soc.getPassword().equals(password)){
                filteredList.add(soc);
            }
        }
        return filteredList;
    }
    
    @Override
    public ArrayList<Socio> getSociosConWhere(String user, String password){
        Session session = null;
        ArrayList<Socio> socios = null;
        try{
            session = NewHibernateUtil.getSessionFactory().openSession();
            Query query = session.createQuery("from Socio where usuario =:user and password =:password");
            query.setParameter("user", user);
            query.setParameter("password", password);
            //String hql="Select log.userId from Login log where log.username=:username and log.password=:password"
            socios = (ArrayList<Socio>) query.list();
        } catch (HibernateException HE){
            System.err.println(HE.getCause());
            System.err.println("Error doing a usuario select.");
        } finally {
            if (session != null){
                session.close();
            }
        }
        return socios;
    }
    

    @Override
    public void insertSocio(Socio socio) {
        Session session = null;
        try{
            session = NewHibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.save(socio);
            session.getTransaction().commit();
        } catch (HibernateException HE){
            System.err.println(HE.getMessage());
            System.err.println("Error inserting the socio");
            session.getTransaction().rollback();
        } finally {
            if (session != null){
                session.close();
            }
        }
    }

    @Override
    public void editSocio(Socio socio) {
        Session session = null;
        try{
            session = NewHibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.update(socio);
            session.getTransaction().commit();
        } catch (HibernateException HE){
            System.err.println(HE.getMessage());
            System.err.println("Error updating the socio");
            session.getTransaction().rollback();
        } finally {
            if (session != null){
                session.close();
            }
        }
    }

    @Override
    public void deleteSocio(Socio socio) {
        Session session = null;
        try{
            session = NewHibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.delete(socio);
            session.getTransaction().commit();
        } catch (HibernateException HE){
            System.err.println(HE.getMessage());
            System.err.println("Error deleting the socio");
            session.getTransaction().rollback();
        } finally {
            if (session != null){
                session.close();
            }
        }
    }

    @Override
    public String nombreSocio(int id) {
        String nombre = null;
        ArrayList<Socio> socios = getSocios();
        
        for(Socio s: socios){
            if(s.getCodSocio()== id){
                nombre = s.getNombre();
                break;
            }
        }
        
        return nombre;
        
    }
}
