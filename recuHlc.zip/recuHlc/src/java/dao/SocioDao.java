/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.Socio;
import java.util.ArrayList;
import java.util.List;

public interface SocioDao {
    public ArrayList<Socio> getSocios();
    public ArrayList<Socio> getSocios(String user, String password);
    public ArrayList<Socio> getSociosConWhere(String user, String password);
    public void insertSocio(Socio socio);
    public void editSocio(Socio socio);
    public void deleteSocio(Socio socio);
    public String nombreSocio(int id);
    
}
