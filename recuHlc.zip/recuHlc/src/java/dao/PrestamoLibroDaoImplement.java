/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import model.PrestamoLibro;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import persistence.NewHibernateUtil;

public class PrestamoLibroDaoImplement implements PrestamoLibroDao{

    @Override
    public ArrayList<PrestamoLibro> getPrestamoLibros() {
        Session session = null;
        ArrayList<PrestamoLibro> prestamosLibros = null;
        try {
            session = NewHibernateUtil.getSessionFactory().openSession();
            Query query = session.createQuery("from PrestamoLibro");
            prestamosLibros = (ArrayList<PrestamoLibro>) query.list();
        } catch (HibernateException HE) {
            System.err.println(HE.getCause());
            System.err.println("Error doing a trabajo select.");
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return prestamosLibros;
    }

    @Override
    public ArrayList<PrestamoLibro> getPrestamosLibros(int id) {
       ArrayList<PrestamoLibro> prestamosLibros = new ArrayList<>();
        ArrayList<PrestamoLibro> filteredList = new ArrayList<>();
        prestamosLibros = getPrestamoLibros();
        for (PrestamoLibro p : prestamosLibros) {
            if(p.getId().getCodPre()== id){
                filteredList.add(p);
            }
        }
        return filteredList;
    }

    @Override
    public PrestamoLibro getPrestamoLibro(int id) {
        PrestamoLibro prestamoLibro = null;
        ArrayList<PrestamoLibro> prestamoLibros = getPrestamoLibros();
        
        for(PrestamoLibro p: prestamoLibros){
            if(p.getId().getCodPre()== id){
                prestamoLibro= p;
                break;
            }
        }
        
        return prestamoLibro;        
    }
    
}
