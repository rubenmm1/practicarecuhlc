/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.Prestamo;
import persistence.NewHibernateUtil;
import java.util.ArrayList;
import java.util.Objects;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

public class PrestamoDaoImplement implements PrestamoDao {

    @Override
    public ArrayList<Prestamo> getPrestamos() {
        Session session = null;
        ArrayList<Prestamo> prestamos = null;
        try {
            session = NewHibernateUtil.getSessionFactory().openSession();
            Query query = session.createQuery("from Prestamo");
            prestamos = (ArrayList<Prestamo>) query.list();
        } catch (HibernateException HE) {
            System.err.println(HE.getCause());
            System.err.println("Error doing a trabajo select.");
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return prestamos;
    }

    @Override
    public void insertPrestamo(Prestamo prestamo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void editPrestamo(Prestamo prestamo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Prestamo> getPrestamoByUsuario(Integer usuarioNumero) {
        ArrayList<Prestamo> prestamos = new ArrayList<>();
        ArrayList<Prestamo> filteredList = new ArrayList<>();
        prestamos = getPrestamos();
        for (Prestamo p : prestamos) {
            if (Objects.equals(p.getCodSoc(), usuarioNumero)) {
                filteredList.add(p);
            }
        }
        return filteredList;
    }
    
    public int getIDPrestamos(Integer usuarioNumero) {
        ArrayList<Prestamo> prestamos = new ArrayList<>();
        int idPrestamo = 0;
        prestamos = getPrestamos();
        for (Prestamo p : prestamos) {
            if (Objects.equals(p.getCodSoc(), usuarioNumero)) {
                idPrestamo=p.getCodPrestamo();
            }
        }
        return idPrestamo;
    }
    

}
